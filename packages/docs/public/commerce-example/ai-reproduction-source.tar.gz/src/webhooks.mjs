import { createHmac, timingSafeEqual } from "node:crypto";
import { DatabaseSync } from "node:sqlite";
import { WEBHOOK } from "openiap-commerce-protocol";
import { valid } from "./contract.mjs";
import { transaction } from "./storage.mjs";
export function sign({ secret, timestamp, body }) {
  return (
    "v1=" +
    createHmac("sha256", secret)
      .update(String(timestamp) + ".")
      .update(body)
      .digest("hex")
  );
}
export function verify({ body, timestamp, signature, secrets, now }) {
  if (
    !/^\d+$/.test(String(timestamp)) ||
    !Number.isSafeInteger(Number(timestamp)) ||
    Math.abs(now - Number(timestamp)) > WEBHOOK.toleranceSeconds ||
    typeof signature !== "string"
  )
    return false;
  return secrets.some((secret) =>
    signature
      .split(",")
      .map((v) => v.trim())
      .some(
        (value) =>
          /^v1=[0-9a-f]{64}$/.test(value) &&
          timingSafeEqual(
            Buffer.from(value),
            Buffer.from(sign({ secret, timestamp, body })),
          ),
      ),
  );
}
export function delivery({ event, body, timestamp, secrets, deliveryId }) {
  return {
    method: "POST",
    contentType: "application/json",
    headers: {
      "content-type": "application/json",
      [WEBHOOK.timestampHeader]: String(timestamp),
      [WEBHOOK.signatureHeader]: secrets
        .map((secret) => sign({ secret, timestamp, body }))
        .join(","),
      [WEBHOOK.eventIdHeader]: event.eventId,
      [WEBHOOK.deliveryIdHeader]: deliveryId,
    },
  };
}
export function classifyResponse(status) {
  return status >= 200 && status < 300
    ? "delivered"
    : status === "timeout" ||
        status === "connection-error" ||
        status === 408 ||
        status === 429 ||
        (status >= 500 && status <= 599)
      ? "retry"
      : "permanent-failure";
}
export function entitled({ state, expiresAt, processedAt }) {
  return (
    ["Active", "InGracePeriod"].includes(state) &&
    (expiresAt === undefined || processedAt < expiresAt)
  );
}
export function emission({ lifecycleEvent, entitledBefore, entitledAfter }) {
  return [
    ...(lifecycleEvent ? [lifecycleEvent] : []),
    ...(entitledBefore === entitledAfter
      ? []
      : [entitledAfter ? "entitlement.granted" : "entitlement.revoked"]),
  ];
}
export function coalesceAtBinding({ entitledAtBinding }) {
  return entitledAtBinding ? ["entitlement.granted"] : [];
}
export const eventsAdapter = {
  sign,
  verify,
  delivery,
  classifyResponse,
  entitled,
  emission,
  coalesceAtBinding,
};
export class Inbox {
  constructor(path, secret, { now = Date.now } = {}) {
    this.db = new DatabaseSync(path);
    this.secret = secret;
    this.now = now;
    this.failNext = 0;
    this.lostAckNext = 0;
    this.alwaysFail = false;
    this.db.exec(
      `PRAGMA journal_mode=WAL; CREATE TABLE IF NOT EXISTS inbox (emitter TEXT NOT NULL, project_id TEXT NOT NULL, event_id TEXT NOT NULL, body TEXT NOT NULL, received_at INTEGER NOT NULL, PRIMARY KEY(emitter,project_id,event_id)); CREATE TABLE IF NOT EXISTS erased_events (emitter TEXT NOT NULL, project_id TEXT NOT NULL, event_id TEXT NOT NULL, PRIMARY KEY(emitter,project_id,event_id));`,
    );
  }
  receive(headers, raw) {
    if (
      headers["content-encoding"] &&
      headers["content-encoding"] !== "identity"
    )
      return { status: 415, body: { accepted: false } };
    if (headers["content-type"]?.split(";")[0] !== "application/json")
      return { status: 415, body: { accepted: false } };
    if (
      !headers[WEBHOOK.eventIdHeader] ||
      !headers[WEBHOOK.deliveryIdHeader] ||
      !verify({
        body: raw,
        timestamp: headers[WEBHOOK.timestampHeader],
        signature: headers[WEBHOOK.signatureHeader],
        secrets: [this.secret],
        now: Math.floor(this.now() / 1000),
      })
    )
      return { status: 401, body: { accepted: false } };
    let event;
    try {
      event = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(raw));
    } catch {
      return { status: 400, body: { accepted: false } };
    }
    if (
      !valid("#/$defs/CommerceEvent", event) ||
      event.eventVersion.split(".")[0] !== "1"
    )
      return { status: 400, body: { accepted: false } };
    if (event.projectId !== "fieldnotes-local")
      return { status: 403, body: { accepted: false } };
    if (
      this.db
        .prepare(
          "SELECT 1 FROM erased_events WHERE emitter=? AND project_id=? AND event_id=?",
        )
        .get("fieldnotes-emitter", event.projectId, event.eventId)
    )
      return { status: 200, body: { accepted: true, duplicate: true } };
    if (this.alwaysFail || this.failNext-- > 0)
      return { status: 503, body: { accepted: false } };
    const inserted = this.db
      .prepare("INSERT OR IGNORE INTO inbox VALUES (?,?,?,?,?)")
      .run(
        "fieldnotes-emitter",
        event.projectId,
        event.eventId,
        raw.toString("utf8"),
        this.now(),
      );
    return {
      status: 200,
      body: { accepted: true, duplicate: inserted.changes === 0 },
      lostAck: this.lostAckNext-- > 0,
    };
  }
  erase(userId) {
    transaction(this.db, () => {
      // Keep only scoped event IDs so a delayed retry cannot restore erased data.
      this.db
        .prepare(
          "INSERT OR IGNORE INTO erased_events SELECT emitter,project_id,event_id FROM inbox WHERE json_extract(body, '$.userId')=?",
        )
        .run(userId);
      this.db
        .prepare("DELETE FROM inbox WHERE json_extract(body, '$.userId')=?")
        .run(userId);
    });
  }
  count() {
    return this.db.prepare("SELECT count(*) AS n FROM inbox").get().n;
  }
  close() {
    this.db.close();
  }
}
export async function deliverPending(
  commerce,
  url,
  secret,
  { now = Date.now, baseBackoffMs = 1000, maxAttempts = 4 } = {},
) {
  // A fixed loopback receiver is the explicit local fixture exception to §9.4.5.
  if (!/^http:\/\/127\.0\.0\.1:\d+\/webhooks\/commerce$/.test(url))
    throw new Error("Only the fixed local fixture receiver is allowed");
  const rows = commerce.db
    .prepare(
      "SELECT * FROM outbox WHERE status='pending' AND next_at<=? ORDER BY rowid",
    )
    .all(now());
  const results = [];
  for (const row of rows) {
    const timestamp = Math.floor(now() / 1000);
    const envelope = delivery({
      event: JSON.parse(row.body),
      body: row.body,
      timestamp,
      secrets: [secret],
      deliveryId: row.delivery_id,
    });
    let status;
    try {
      status = (
        await fetch(url, {
          method: envelope.method,
          headers: envelope.headers,
          body: row.body,
          redirect: "manual",
          signal: AbortSignal.timeout(3000),
        })
      ).status;
    } catch {
      status = "connection-error";
    }
    const action = classifyResponse(status);
    const attempts = row.attempts + 1;
    const state =
      action === "delivered"
        ? "delivered"
        : action === "permanent-failure" || attempts >= maxAttempts
          ? "dead-letter"
          : "pending";
    const nextAt =
      state === "pending" ? now() + baseBackoffMs * 2 ** (attempts - 1) : 0;
    commerce.db
      .prepare(
        "UPDATE outbox SET status=?, attempts=?, next_at=? WHERE event_id=?",
      )
      .run(state, attempts, nextAt, row.event_id);
    commerce.db
      .prepare(
        "INSERT INTO delivery_attempts(event_id,delivery_id,timestamp,signature,http_status,result,body) VALUES (?,?,?,?,?,?,?)",
      )
      .run(
        row.event_id,
        row.delivery_id,
        timestamp,
        envelope.headers[WEBHOOK.signatureHeader],
        String(status),
        state,
        row.body,
      );
    results.push({
      eventId: row.event_id,
      deliveryId: row.delivery_id,
      attempt: attempts,
      httpStatus: status,
      result: state,
      nextAt,
    });
  }
  return results;
}
