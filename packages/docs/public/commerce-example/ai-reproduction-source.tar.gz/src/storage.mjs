import { DatabaseSync } from "node:sqlite";
export const INITIAL_TIME = Date.parse("2026-09-09T09:00:00Z");
export function openStore(path) {
  const db = new DatabaseSync(path);
  db.exec(`PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;
    CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS purchases (token TEXT PRIMARY KEY, user_id TEXT, product_id TEXT NOT NULL, state TEXT NOT NULL, expires_at INTEGER NOT NULL, will_renew INTEGER NOT NULL, started_at INTEGER NOT NULL, updated_at INTEGER NOT NULL, last_gate INTEGER NOT NULL DEFAULT 1, erased INTEGER NOT NULL DEFAULT 0);
    CREATE TABLE IF NOT EXISTS observations (id TEXT PRIMARY KEY, kind TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS delivery_attempts (id INTEGER PRIMARY KEY, event_id TEXT NOT NULL, delivery_id TEXT NOT NULL, timestamp INTEGER NOT NULL, signature TEXT NOT NULL, http_status TEXT NOT NULL, result TEXT NOT NULL, body TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS outbox (event_id TEXT PRIMARY KEY, delivery_id TEXT NOT NULL UNIQUE, body TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending', attempts INTEGER NOT NULL DEFAULT 0, next_at INTEGER NOT NULL DEFAULT 0);
  `);
  if (
    !db
      .prepare("PRAGMA table_info(purchases)")
      .all()
      .some((c) => c.name === "last_gate")
  )
    db.exec(
      "ALTER TABLE purchases ADD COLUMN last_gate INTEGER NOT NULL DEFAULT 1",
    );
  if (
    !db
      .prepare("PRAGMA table_info(purchases)")
      .all()
      .some((c) => c.name === "erased")
  )
    db.exec(
      "ALTER TABLE purchases ADD COLUMN erased INTEGER NOT NULL DEFAULT 0",
    );
  db.prepare("INSERT OR IGNORE INTO settings VALUES (?,?)").run(
    "clock",
    String(INITIAL_TIME),
  );
  return db;
}
export function transaction(db, fn) {
  db.exec("BEGIN IMMEDIATE");
  try {
    const value = fn();
    db.exec("COMMIT");
    return value;
  } catch (error) {
    db.exec("ROLLBACK");
    throw error;
  }
}
