export const PRODUCT = "fieldnotes.premium.monthly";
export const PERIOD = 30 * 24 * 60 * 60 * 1000;
export const users = { alice: "user_alice", bob: "user_bob" };
export const TOKENS = {
  alice: "fictional-alice-premium",
  bob: "fictional-bob-premium",
  pending: "fictional-pending",
  invalid: "fictional-invalid",
  outage: "fictional-outage",
};
export const credentials = {
  server: "local-fixture-server-key",
  verification: "local-fixture-verification-key",
};
export function evidence(token) {
  return { store: "google", google: { purchaseToken: token } };
}
export function fixtureOwner(token) {
  return token === TOKENS.alice
    ? users.alice
    : token === TOKENS.bob
      ? users.bob
      : undefined;
}
