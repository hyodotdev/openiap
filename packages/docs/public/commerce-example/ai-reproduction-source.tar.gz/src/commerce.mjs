import { bundleSchema, HTTP_BINDING } from "openiap-commerce-protocol";
import { entitled, emission, coalesceAtBinding } from "./webhooks.mjs";
import { randomUUID } from "node:crypto";
import { PRODUCT, PERIOD, TOKENS, fixtureOwner } from "./fixtures.mjs";
import { openStore, transaction } from "./storage.mjs";
import { checked, ProtocolError } from "./contract.mjs";
export class Commerce {
  constructor(path) {
    this.path = path;
    this.db = openStore(path);
  }
  now() {
    return Number(
      this.db.prepare("SELECT value FROM settings WHERE key=?").get("clock")
        .value,
    );
  }
  counts() {
    return Object.fromEntries(
      ["purchases", "observations", "outbox"].map((table) => [
        table,
        this.db.prepare(`SELECT COUNT(*) AS n FROM ${table}`).get().n,
      ]),
    );
  }
  capabilities() {
    const axes = bundleSchema.$defs.CapabilitiesStoreCapabilities.required;
    const stores = {
      google: Object.fromEntries(
        axes.map((axis) => [
          axis,
          {
            provider: true,
            implementation: [
              "initialValidation",
              "subscriptions",
              "entitlements",
            ].includes(axis),
            notes:
              "Fixture-only descriptor: Google-shaped evidence and local subscription records. No Google API or store notification integration.",
          },
        ]),
      ),
    };
    return checked("#/$defs/ProviderCapabilities", {
      specVersion: HTTP_BINDING.protocolVersion,
      fixtureOnly: true,
      profiles: HTTP_BINDING.profiles,
      bindings: { rest: HTTP_BINDING.bindings.rest },
      implementation: {
        name: "Field Notes local fixture backend",
        version: "0.1.0",
      },
      eventTypes:
        bundleSchema.$defs.CommerceEvent.properties.eventType.examples,
      stores,
    });
  }

  verify(input) {
    const token = input.google.purchaseToken;
    if (token === TOKENS.outage)
      throw new ProtocolError(
        "VERIFICATION_FAILED",
        "The fixture verifier is temporarily unavailable.",
      );
    if (token === TOKENS.pending)
      return {
        store: "google",
        isValid: false,
        state: "PENDING",
        environment: "fixture",
      };
    if (!fixtureOwner(token))
      return {
        store: "google",
        isValid: false,
        state: "INAUTHENTIC",
        environment: "fixture",
      };
    transaction(this.db, () => {
      const inserted = this.db
        .prepare(
          "INSERT OR IGNORE INTO purchases (token,user_id,product_id,state,expires_at,will_renew,started_at,updated_at) VALUES (?,NULL,?,?,?,?,?,?)",
        )
        .run(
          token,
          PRODUCT,
          "Active",
          this.now() + PERIOD,
          1,
          this.now(),
          this.now(),
        );
      if (inserted.changes)
        this.queue(this.purchase(token), "subscription.started", this.now());
    });
    return {
      store: "google",
      isValid: true,
      state: "ENTITLED",
      productId: PRODUCT,
      environment: "fixture",
    };
  }
  snapshot(row) {
    const active = entitled({
      state: row.state,
      expiresAt: row.expires_at,
      processedAt: this.now(),
    });
    return {
      productId: row.product_id,
      state: row.state,
      active,
      store: "google",
      expiresAt: row.expires_at,
      willRenew: Boolean(row.will_renew),
      ...(row.will_renew ? { renewsAt: row.expires_at } : {}),
      startedAt: row.started_at,
      updatedAt: row.updated_at,
    };
  }
  records(userId) {
    return this.db
      .prepare(
        "SELECT * FROM purchases WHERE user_id=? ORDER BY updated_at DESC, token",
      )
      .all(userId)
      .map((row) => this.snapshot(row));
  }
  status(userId) {
    const rows = this.records(userId);
    const subscription = rows.find((row) => row.active) || rows[0];
    return checked("#/$defs/SubscriptionStatusResult", {
      active: rows.some((row) => row.active),
      ...(subscription ? { subscription } : {}),
    });
  }
  entitlements(userId) {
    const subscriptions = this.records(userId).filter((row) => row.active);
    return checked("#/$defs/EntitlementsResult", {
      userId,
      productIds: [...new Set(subscriptions.map((row) => row.productId))],
      subscriptions,
    });
  }
  bind(input) {
    const token = input.google.purchaseToken;
    if (fixtureOwner(token) !== input.userId) return { bound: false };
    return transaction(this.db, () => {
      const before = this.purchase(token);
      const result = this.db
        .prepare(
          "UPDATE purchases SET user_id=? WHERE token=? AND erased=0 AND (user_id IS NULL OR user_id=?)",
        )
        .run(input.userId, token, input.userId);
      if (result.changes && !before.user_id) {
        const row = this.purchase(token);
        for (const eventType of coalesceAtBinding({
          entitledAtBinding: this.snapshot(row).active,
        }))
          this.queue(row, eventType, row.started_at);
        this.db
          .prepare("UPDATE purchases SET last_gate=? WHERE token=?")
          .run(Number(this.snapshot(row).active), token);
      }
      return { bound: result.changes === 1 };
    });
  }
  erase(userId) {
    return transaction(this.db, () => {
      // Delete immutable event bodies instead of changing a signed retry's payload.
      this.db
        .prepare(
          "DELETE FROM delivery_attempts WHERE json_extract(body, '$.userId')=?",
        )
        .run(userId);
      this.db
        .prepare("DELETE FROM outbox WHERE json_extract(body, '$.userId')=?")
        .run(userId);
      this.db
        .prepare("UPDATE purchases SET user_id=NULL, erased=1 WHERE user_id=?")
        .run(userId);
      return checked("#/$defs/EraseUserResult", { accepted: true });
    });
  }
  purchase(token) {
    return this.db.prepare("SELECT * FROM purchases WHERE token=?").get(token);
  }
  queue(row, eventType, occurredAt) {
    const snapshot = this.snapshot(row);
    const { productId, state, active, expiresAt, willRenew, renewsAt } =
      snapshot;
    const event = checked("#/$defs/CommerceEvent", {
      eventId: randomUUID(),
      eventType,
      eventVersion: "1.0",
      occurredAt,
      processedAt: this.now(),
      store: "google",
      environment: "fixture",
      projectId: "fieldnotes-local",
      productId,
      ...(row.user_id ? { userId: row.user_id } : {}),
      subscription: {
        productId,
        state,
        active,
        expiresAt,
        willRenew,
        ...(renewsAt ? { renewsAt } : {}),
      },
    });
    this.db
      .prepare("INSERT INTO outbox (event_id,delivery_id,body) VALUES (?,?,?)")
      .run(event.eventId, randomUUID(), JSON.stringify(event));
    return event;
  }
  setTime(time) {
    if (!Number.isSafeInteger(time) || time < this.now())
      throw new ProtocolError(
        "INVALID_REQUEST",
        "The fixture clock only moves forward.",
      );
    this.db
      .prepare("UPDATE settings SET value=? WHERE key=?")
      .run(String(time), "clock");
  }
  observe(token, kind, observationId, fail = false) {
    return transaction(this.db, () => {
      if (
        this.db
          .prepare("SELECT id FROM observations WHERE id=?")
          .get(observationId)
      )
        return { duplicate: true };
      const before = this.purchase(token);
      if (!before || !["cancel", "expire"].includes(kind))
        throw new ProtocolError(
          "INVALID_REQUEST",
          "Unknown fixture observation.",
        );
      if (kind === "expire" && this.now() < before.expires_at)
        throw new ProtocolError(
          "INVALID_REQUEST",
          "The paid period has not ended.",
        );
      const changed =
        kind === "cancel"
          ? Boolean(before.will_renew)
          : before.state !== "Expired";
      this.db
        .prepare("INSERT INTO observations VALUES (?,?)")
        .run(observationId, kind);
      if (!changed) return { duplicate: false, changed: false };
      this.db
        .prepare(
          "UPDATE purchases SET will_renew=0, state=?, updated_at=? WHERE token=?",
        )
        .run(kind === "expire" ? "Expired" : before.state, this.now(), token);
      const row = this.purchase(token);
      const active = this.snapshot(row).active;
      for (const eventType of emission({
        lifecycleEvent:
          kind === "cancel" ? "subscription.canceled" : "subscription.expired",
        entitledBefore: row.user_id ? Boolean(before.last_gate) : active,
        entitledAfter: active,
      }))
        this.queue(
          row,
          eventType,
          kind === "expire" ? row.expires_at : this.now(),
        );
      this.db
        .prepare("UPDATE purchases SET last_gate=? WHERE token=?")
        .run(Number(active), token);
      if (fail) throw new Error("Injected transaction failure");
      return { duplicate: false, changed: true };
    });
  }
  lifecycle(userId, kind) {
    const row = this.db
      .prepare(
        "SELECT * FROM purchases WHERE user_id=? ORDER BY updated_at DESC LIMIT 1",
      )
      .get(userId);
    if (!row)
      throw new ProtocolError(
        "INVALID_REQUEST",
        "Buy Premium for this fixture user first.",
      );
    if (kind === "expire") this.setTime(Math.max(this.now(), row.expires_at));
    this.observe(row.token, kind, `${kind}:${row.token}`);
    return this.status(userId);
  }
  inspect() {
    return {
      clock: this.now(),
      ...this.counts(),
      stage: "Signed delivery",
      deliveryAttempts: this.db
        .prepare(
          "SELECT event_id,delivery_id,timestamp,http_status,result FROM delivery_attempts ORDER BY id",
        )
        .all(),
      events: this.db
        .prepare(
          "SELECT event_id, status, attempts, body FROM outbox ORDER BY rowid",
        )
        .all()
        .map((r) => ({ ...r, body: JSON.parse(r.body) })),
      fixture: true,
      alice: this.status("user_alice"),
      bob: this.status("user_bob"),
    };
  }
  close() {
    this.db.close();
  }
}
