import http from "node:http";
import { readFileSync, mkdirSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { Commerce } from "./commerce.mjs";
import { HTTP_BINDING, checked, problem, ProtocolError } from "./contract.mjs";
import { Inbox, deliverPending } from "./webhooks.mjs";
import { randomUUID, randomBytes } from "node:crypto";
import { credentials, users, TOKENS, evidence } from "./fixtures.mjs";
import { valid } from "./contract.mjs";
export async function startServer({
  port = 0,
  database = ":memory:",
  wallNow = Date.now,
  retryBase = 1000,
  autoDeliver = false,
} = {}) {
  const commerce = new Commerce(database);
  const sessions = new Map();
  commerce.db
    .prepare("INSERT OR IGNORE INTO settings VALUES (?,?)")
    .run("webhook-secret", randomBytes(32).toString("hex"));
  const secret = commerce.db
    .prepare("SELECT value FROM settings WHERE key=?")
    .get("webhook-secret").value;
  const inbox = new Inbox(
    database === ":memory:" ? ":memory:" : database + ".inbox.sqlite",
    secret,
    { now: wallNow },
  );
  let delivering;
  const dispatch = () =>
    (delivering ||= deliverPending(
      commerce,
      `http://127.0.0.1:${server.address().port}/webhooks/commerce`,
      secret,
      { now: wallNow, baseBackoffMs: retryBase },
    ).finally(() => {
      delivering = null;
    }));
  const eraseIdentity = async (userId) => {
    if (delivering) await delivering;
    return commerce.erase(userId);
  };
  const server = http.createServer(async (req, res) => {
    const send = (status, body) => {
      res.writeHead(status, {
        "content-type": "application/json",
        "cache-control": "no-store",
      });
      res.end(JSON.stringify(body));
    };
    try {
      const base = `http://${req.headers.host}`;
      if (!["127.0.0.1", "localhost"].includes(new URL(base).hostname))
        throw new ProtocolError("FORBIDDEN", "Loopback only.");
      if (req.headers.origin && req.headers.origin !== base)
        throw new ProtocolError("FORBIDDEN", "Same-origin requests only.");
      const url = new URL(req.url, base);
      if (url.pathname === "/webhooks/commerce" && req.method === "POST") {
        const chunks = [];
        let bytes = 0;
        for await (const chunk of req) {
          bytes += chunk.length;
          if (bytes > 65536) return send(413, { accepted: false });
          chunks.push(chunk);
        }
        const result = inbox.receive(req.headers, Buffer.concat(chunks));
        if (result.lostAck) {
          req.socket.destroy();
          return;
        }
        return send(result.status, result.body);
      }
      const sessionId = req.headers.cookie
        ?.split("; ")
        .find((v) => v.startsWith("fieldnotes="))
        ?.slice("fieldnotes=".length);
      const sessionUser = sessions.get(sessionId);
      const body = async () => {
        if (req.headers["content-type"]?.split(";")[0] !== "application/json")
          throw new ProtocolError("INVALID_REQUEST", "Use application/json.");
        const chunks = [];
        let bytes = 0;
        for await (const chunk of req) {
          bytes += chunk.length;
          if (bytes > 32768)
            throw new ProtocolError(
              "INVALID_REQUEST",
              "Request body is too large.",
            );
          chunks.push(chunk);
        }
        try {
          return JSON.parse(Buffer.concat(chunks).toString("utf8"));
        } catch {
          throw new ProtocolError(
            "INVALID_REQUEST",
            "A JSON body is required.",
          );
        }
      };
      if (req.method === "POST" && url.pathname === "/api/session") {
        const input = await body();
        if (!Object.hasOwn(users, input.alias))
          throw new ProtocolError("INVALID_REQUEST", "Choose a fixture user.");
        if (sessionId) sessions.delete(sessionId);
        const id = randomUUID();
        sessions.set(id, users[input.alias]);
        res.setHeader(
          "set-cookie",
          `fieldnotes=${id}; HttpOnly; SameSite=Strict; Path=/`,
        );
        return send(200, { userId: users[input.alias] });
      }
      if (url.pathname === "/api/me" && req.method === "GET")
        return send(200, {
          userId: sessionUser || null,
          ...(sessionUser
            ? {
                status: commerce.status(sessionUser),
                entitlements: commerce.entitlements(sessionUser),
              }
            : {}),
        });
      if (url.pathname === "/api/premium-note" && req.method === "GET") {
        if (!sessionUser)
          throw new ProtocolError(
            "UNAUTHORIZED",
            "Choose a fixture user first.",
          );
        if (!commerce.status(sessionUser).active)
          throw new ProtocolError("FORBIDDEN", "Premium access is required.");
        return send(200, {
          title: "The quiet morning",
          text: "Some thoughts need more room. Take the long path home. Remember the light on the water.",
        });
      }
      if (url.pathname.startsWith("/api/") && req.method === "POST") {
        if (!sessionUser)
          throw new ProtocolError(
            "UNAUTHORIZED",
            "Choose a fixture user first.",
          );
        const input = await body();
        if (url.pathname === "/api/checkout") {
          const scenario = input.scenario || "paid";
          if (scenario === "canceled")
            return send(200, {
              outcome: "canceled",
              message: "Checkout canceled. No purchase was made.",
            });
          const token =
            scenario === "paid"
              ? TOKENS[sessionUser === users.alice ? "alice" : "bob"]
              : TOKENS[scenario];
          if (!token)
            throw new ProtocolError(
              "INVALID_REQUEST",
              "Unknown fixture scenario.",
            );
          const purchase = evidence(token);
          const verdict = checked(
            "#/$defs/VerifyPurchaseResult",
            commerce.verify(purchase),
          );
          if (!verdict.isValid)
            return send(200, {
              outcome: verdict.state === "PENDING" ? "pending" : "failed",
              verdict,
              message:
                verdict.state === "PENDING"
                  ? "Purchase pending. Premium stays locked until verification succeeds."
                  : "Evidence rejected. Premium stays locked.",
            });
          const binding = commerce.bind({ ...purchase, userId: sessionUser });
          const access = commerce.entitlements(sessionUser);
          return send(200, {
            outcome:
              binding.bound && access.productIds.length
                ? "fulfilled"
                : "unfulfilled",
            verdict,
            binding,
            access,
            message: access.productIds.length
              ? "Premium is ready. Your paid access is confirmed."
              : "This purchase did not grant access.",
          });
        }
        if (url.pathname === "/api/erase") {
          const result = await eraseIdentity(sessionUser);
          inbox.erase(sessionUser);
          for (const [id, user] of sessions)
            if (user === sessionUser) sessions.delete(id);
          res.setHeader(
            "set-cookie",
            "fieldnotes=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0",
          );
          return send(200, {
            ...result,
            message:
              "Account data erased from this provider and the app’s inbox. Existing sessions are signed out.",
          });
        }
        if (url.pathname === "/api/deliver")
          return send(200, {
            attempts: await dispatch(),
            message:
              "Due events were signed and sent to the durable local inbox.",
          });
        if (url.pathname === "/api/cancel")
          return send(200, {
            status: commerce.lifecycle(sessionUser, "cancel"),
            message:
              "Renewal is off. Paid Premium access remains until expiry.",
          });
        if (url.pathname === "/api/expire")
          return send(200, {
            status: commerce.lifecycle(sessionUser, "expire"),
            message: "The fixture clock reached expiry. Premium is now locked.",
          });
        if (url.pathname === "/api/claim-alice")
          return send(200, {
            ...commerce.bind({
              ...evidence(TOKENS.alice),
              userId: sessionUser,
            }),
            message:
              "Ownership stays with the fixture purchaser. No transfer is allowed.",
          });
      }
      if (req.method === "GET" && url.pathname === "/") {
        res.writeHead(200, { "content-type": "text/html; charset=utf-8" });
        res.end(readFileSync(new URL("../public/index.html", import.meta.url)));
        return;
      }
      if (req.method === "GET" && url.pathname === "/api/demo")
        return send(200, { ...commerce.inspect(), inbox: inbox.count() });
      const operation = HTTP_BINDING.operations.find(
        (op) => op.path === url.pathname && op.method === req.method,
      );
      if (operation?.name === "providerCapabilities")
        return send(
          operation.successStatus,
          checked(operation.result, commerce.capabilities()),
        );
      if (operation) {
        const credential = req.headers.authorization?.replace(/^Bearer /, "");
        const role = Object.keys(credentials).find(
          (role) => credentials[role] === credential,
        );
        if (!role)
          throw new ProtocolError(
            "UNAUTHORIZED",
            "A valid credential is required.",
          );
        if (operation.auth === "server" && role !== "server")
          throw new ProtocolError(
            "FORBIDDEN",
            "A server credential is required.",
          );
        const input =
          req.method === "GET"
            ? Object.fromEntries(url.searchParams)
            : await body();
        if (!valid(operation.input, input))
          throw new ProtocolError(
            "INVALID_REQUEST",
            "The request does not match the operation schema.",
          );
        if (
          "store" in Object(input) &&
          typeof input.store === "string" &&
          input.store !== "google"
        )
          throw new ProtocolError(
            "UNSUPPORTED_STORE",
            "This fixture adapter supports Google-shaped evidence only.",
          );
        if (operation.name === "verifyPurchase")
          return send(
            operation.successStatus,
            checked(operation.result, commerce.verify(input)),
          );
        if (operation.name === "bindPurchase")
          return send(200, checked(operation.result, commerce.bind(input)));
        if (operation.name === "subscriptionStatus")
          return send(
            200,
            checked(operation.result, commerce.status(input.userId)),
          );
        if (operation.name === "entitlements")
          return send(
            200,
            checked(operation.result, commerce.entitlements(input.userId)),
          );
        if (operation.name === "eraseUser")
          return send(
            operation.successStatus,
            checked(operation.result, await eraseIdentity(input.userId)),
          );
        throw new ProtocolError("NOT_FOUND", "Unknown operation.");
      }
      throw new ProtocolError("NOT_FOUND", "Endpoint not found.");
    } catch (error) {
      const failure = problem(error);
      send(failure.status, failure.body);
    }
  });
  await new Promise((resolve) => server.listen(port, "127.0.0.1", resolve));
  const worker = autoDeliver
    ? setInterval(
        () =>
          dispatch().catch((error) =>
            console.error("Delivery worker failed:", error.message),
          ),
        1000,
      )
    : null;
  worker?.unref();
  return {
    server,
    commerce,
    inbox,
    secret,
    dispatch,
    url: `http://127.0.0.1:${server.address().port}`,
    close: async () => {
      if (worker) clearInterval(worker);
      if (delivering) await delivering;
      await new Promise((resolve) => server.close(resolve));
      inbox.close();
      commerce.close();
    },
  };
}
if (process.argv[1] === fileURLToPath(import.meta.url)) {
  mkdirSync("data", { recursive: true });
  const app = await startServer({
    port: Number(process.env.PORT || 5197),
    database: process.env.DATABASE || "data/commerce.sqlite",
    autoDeliver: true,
  });
  console.log(`Field Notes fixture demo: ${app.url}`);
  for (const signal of ["SIGTERM", "SIGINT"])
    process.on(signal, async () => {
      await app.close();
      process.exit(0);
    });
}
