import Ajv from "ajv/dist/2020.js";
import { bundleSchema, HTTP_BINDING } from "openiap-commerce-protocol";
export { HTTP_BINDING };
const ajv = new Ajv({ strict: false, allErrors: true });
ajv.addSchema(bundleSchema);
const validators = new Map();
export function valid(pointer, value) {
  if (!validators.has(pointer))
    validators.set(pointer, ajv.compile({ $ref: bundleSchema.$id + pointer }));
  return validators.get(pointer)(value);
}
export class ProtocolError extends Error {
  constructor(code, message) {
    super(message);
    this.code = code;
  }
}
export function problem(error) {
  const code = error instanceof ProtocolError ? error.code : "INTERNAL_ERROR";
  const body = {
    error: {
      code,
      message:
        error instanceof ProtocolError
          ? error.message
          : "Unable to complete this operation.",
    },
  };
  if (!valid(HTTP_BINDING.errorResponse, body))
    throw new Error("Invalid error response");
  return { status: HTTP_BINDING.errorStatus[code], body };
}
export function checked(pointer, value) {
  if (!valid(pointer, value))
    throw new Error(`Contract validation failed: ${pointer}`);
  return value;
}
