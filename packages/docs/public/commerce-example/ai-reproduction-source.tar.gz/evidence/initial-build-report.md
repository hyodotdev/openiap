# Independent implementation record

The supplied brief was sufficient to build the requested local Field Notes flow. This project began empty. Implementation source was written here from the installed contract; no code from existing local OpenIAP or example checkouts was read or copied. The public reference repository was downloaded for its published instructions. All changes remain uncommitted.

## Sources and versions

| Source | Recorded version |
| --- | --- |
| `https://github.com/hyodotdev/openiap-commerce-protocol-example.git` | Shallow clone at `e52900c2f040a0c9aa895e4a605b4f3e84940652` |
| Public instructions read | `INTEGRATE.md`, `BUILD.md`, `docs/receiver.md`, public README and package metadata |
| Installed normative contract | `openiap-commerce-protocol@0.1.0`, protocol `1.0` |
| Contract artifacts used | `SPEC.md`, generated HTTP manifest/OpenAPI, offline bundle schemas, signature and lifecycle vectors, portable conformance runner |
| Runtime | Node `24.16.0`, npm `11.13.0`; Node built-in SQLite |
| Installed dependencies | Ajv `8.20.0`, Playwright `1.63.0` |
| Isolated capture browser | Chrome for Testing `153.0.8010.12`, Playwright Chromium revision `1243`; downloaded under `data/playwright` |

`package-lock.json` pins registry tarballs and integrity hashes. The public clone lives in `reference/` and is not needed to run this app. No `AGENTS.md` or stack files existed in the empty project or in the fetched reference. The original monorepo instructions do not supply implementation source to this reproduction.

## Actual milestones

| Source checkpoint | Actual checks at that point | Result |
| --- | --- | --- |
| `1-contract.tar.gz` | Empty SQLite, real HTTP page/state, schema-valid unfinished-discovery error, database reopen | 1 test group passed |
| `2-verification.tar.gz` | Valid/idempotent purchase, no account binding, pending, negative verdict, outage, missing evidence, unsupported store and missing credential | 2 groups passed |
| `3-ownership.tar.gz` | Session-selected identity, fixture ownership policy, 20 overlapping Alice/Bob HTTP bind attempts, tokenless reads, server-role checks, protected note | 4 groups passed |
| `4-lifecycle.tar.gz` | Cancel retains paid access, expiry-minus-1ms/exact-expiry, delayed expiry observation, duplicate/unchanged observations, atomic write-failure rollback, first bind after expiry | 6 groups passed |
| `5-delivery.tar.gz` | HTTP 503, retry, lost acknowledgement, deduplicated acceptance, immutable retry identities/bytes, fresh signing, tampering, four-attempt dead letter, published vectors | 10 groups passed after the validation-order correction |
| `6-recovery.tar.gz` | Reopen both SQLite databases with pending delivery; persisted secret, ownership, outbox bytes and inbox dedup survive; delivery resumes | 11 groups passed |
| `7-review-fixes.tar.gz` | Clean-source install/test and accurate reload banner after buy/cancel/expiry | Independent review corrections; see logs below |

Each archive is in `evidence/checkpoints/`, with a SHA-256 sidecar. Screens under `evidence/screens/2026-09-08T16-11-15.208Z/` were captured from actual reruns of checkpoints 1–6 in separate local servers. Their report records archive hashes, state and HTTP responses. The original six checkpoints intentionally retain their historical bugs; the seventh contains the reviewed source. Screens are replay evidence, not contemporaneous build recordings.

The fixture test suite currently contains 11 named groups. Published vectors exercised separately are 32 entitlement, 64 emission, 4 first-binding, 5 signing, 6 signature rejections and 24 HTTP response-semantic cases, plus connection/timeout classification. The portable REST runner records 42 cases: 38 pass and 4 fail. Do not add those numbers together as a certification score.

## Commands and observed results

Commands were run from this project unless a clean replay directory is explicitly named in its report:

```sh
git ls-remote https://github.com/hyodotdev/openiap-commerce-protocol-example.git HEAD
git clone --depth 1 https://github.com/hyodotdev/openiap-commerce-protocol-example.git reference
npm init -y
npm install --save-exact openiap-commerce-protocol ajv
npm install --save-dev --save-exact playwright
npm install --package-lock-only
npm test
npm run checkpoint -- 1-contract
# Repeated after each numbered milestone; exact output is under evidence/.
PLAYWRIGHT_BROWSERS_PATH=./data/playwright npx playwright install chromium
PLAYWRIGHT_BROWSERS_PATH=./data/playwright node scripts/capture.mjs
PLAYWRIGHT_BROWSERS_PATH=./data/playwright node scripts/verify-reloads.mjs
npm run conformance
```

Initial npm installation and final lockfile audit reported zero vulnerabilities. `npm ls --depth=0` confirmed the installed versions above. The installed OpenAPI contains all six manifest paths (`evidence/openapi-check.json`). The six-archive screen capture completed with zero page errors. The reload check records three successful reload states and no horizontal overflow at 390px in `evidence/reload-checks.json`.

## Failures and fixes, preserved

1. Reading `conformance/README.md` failed because package 0.1.0 does not ship that file. The brief names the directory, not that filename. The implementation instead read the shipped `index.d.ts`, exports, artifacts and `SPEC.md`. This was a discovery miss, not a brief blocker.
2. The first portable-runner attempt found five failures (`evidence/conformance-attempt-1.json` and `5-delivery-attempt-1.log`). One was actionable: mismatched known-store evidence returned `UNSUPPORTED_STORE` before schema validation. Validation now checks known evidence shape first; the same vector passes on rerun. The four remaining failures are three `eraseUser` checks and the undeclared REST binding. Erasure and complete binding/profile support are explicitly unfinished; the runner report remains `ok: false`, and `npm run conformance` exits 1. Local test success must not be represented as full conformance.
3. The independent reviewer’s clean-source replay found three test failures because `data/` and `evidence/` were assumed to exist. The exact failed output is preserved in `evidence/independent-fresh-tests-failed.log`, with its setup record alongside it. `scripts/test.mjs` now creates both directories before executing tests. A new source-only copy with no dependencies or runtime artifacts was tested with `npm ci --ignore-scripts` and `npm test`; see `evidence/clean-replay.json` and its log.
4. The independent reviewer found that reloading an existing Premium account displayed a hardcoded free-plan banner. Session initialization now derives that message from the same backend access result used by the note and status panel. The three buy/cancel/expiry reload checks pass; `evidence/reload-checks.json` records the actual text and note visibility.

No artificial failures were inserted for presentation. The explicit lifecycle transaction failpoint and receiver fault flags are deterministic negative-test inputs, clearly named in the tests.

## Product and implementation decisions inferred

- One product, `fieldnotes.premium.monthly`, with a fictional display price of $4.99 and a fixed 30-day paid period. This is fixture catalog data, not a Commerce Protocol catalog operation or store-fetched price.
- A plain Node HTTP/SQLite stack and a paper-and-green notes interface, because the project had no existing stack or design system.
- Google-shaped `purchaseToken` evidence containing conspicuously fictional values. No Google API is called. Capability axes explicitly report no real store implementation; events carry `environment: fixture` and no invented revenue amount.
- Opaque IDs `user_alice` / `user_bob`, project scope `fieldnotes-local`, emitter scope `fieldnotes-emitter`. Only the backend chooses bind/read user IDs from its fixture session.
- The fixture purchase-owner registry refuses Bob even before Alice claims her evidence. Possession of a token is not enough. SQLite’s immediate transaction and conditional update preserve the binding across overlapping requests. The concurrency check uses one process, not a multi-host stress test.
- Cancellation switches renewal off. Access uses the provider clock and the exclusive `now < expiresAt` rule. The UI clock action represents a test fixture, not a protocol input from a shipped app.
- A random signing secret is generated on the server and persisted in the commerce database. The receiver authenticates exact raw UTF-8 bytes before parsing, scopes dedup by configured emitter/project and signed body event ID, and durably inserts before acknowledging. Header event IDs are not the authority.
- The local delivery worker uses 1s, 2s, 4s backoff and stops after four attempts. Redirects are not followed. Its only destination is the fixed loopback receiver, an explicit local test exception to public HTTPS requirements.
- Receiver ingestion stores facts only; it does not derive access or count events as revenue. App access reads the authoritative commerce backend. This is bounded request/response, with no backend-to-mobile event stream.
- No real transaction is acknowledged, consumed or finished. A real client adapter must durably fulfill, then finish/acknowledge through the chosen OpenIAP library and store responsibilities. This local browser purchase adapter cannot establish that behavior.

## App connection and file map

`public/index.html` owns presentation and fixture controls. `/api/session` creates an HttpOnly, SameSite fixture session; `/api/checkout` selects fictional evidence on the server, verifies it, binds with the session’s user, reads entitlements, and returns fulfilled/pending/failed/canceled. `/api/premium-note` independently checks current access. The browser never receives the protocol server credential or webhook signing secret.

`src/contract.mjs` loads the published schema and binding manifest. `src/commerce.mjs` owns verification, ownership, access and the atomic observation/outbox transaction. `src/webhooks.mjs` owns signing, delivery and the separate inbox. `src/storage.mjs` owns SQLite setup. `src/server.mjs` connects these through real HTTP, plus local app endpoints. `test/` contains the executable success and failure cases. `scripts/` contains test bootstrap, conformance, captures and replay verification.

To connect a different frontend, call its own authenticated backend. Replace only the fixture evidence/session boundaries; keep server role credentials out of the frontend. The existing `verifyPurchaseWithProvider` helper is not used or assumed to implement this protocol.

## Remaining work and limits

Real store evidence validation/notifications and sandbox purchases; real user authentication and ownership proof; account erasure and already-delivered data responsibility; multi-tenant isolation; complete profiles and binding declaration; public HTTPS destination validation, DNS/address pinning and egress protection; real purchase fulfilment and acknowledgement; store reconciliation, secrets rotation operations, recovery under OS crash/power loss, backup, load and multi-worker behavior.

Recovery here closes and reopens both databases and the HTTP server within one Node test process. It proves persistence and pending-delivery resumption, not crash or machine-loss recovery. The local demo is operator-visible and is not safe to expose as a production service. No cloud resources, real accounts, store credentials, commits, pushes or deployments were used.

## Final review instance

The user-facing server remains running at **http://127.0.0.1:5197** with a new, empty `data/commerce.sqlite` and inbox. Both Alice and Bob start free; `evidence/ready-state.json` records that state and `evidence/ready-desktop.png` captures it. The previously exercised, expired Alice database and its inbox are preserved under `data/exercised/`; its final HTTP state is in `evidence/exercised-demo-state.json`. The live server command is `npm start` from this project, using port 5197. No existing user browser was controlled by this implementation agent; capture used a separate downloaded headless browser and isolated profiles.
