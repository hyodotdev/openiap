import { test } from "node:test";
import assert from "node:assert/strict";
import { mkdtempSync, rmSync } from "node:fs";
import { join } from "node:path";
import { startServer } from "../src/server.mjs";
import { Commerce } from "../src/commerce.mjs";
import { valid } from "../src/contract.mjs";
test("milestone 1: empty persistent storage, real HTTP, discovery declares the implemented profiles and REST binding", async () => {
  const dir = mkdtempSync("data/field-notes-test-");
  const database = join(dir, "commerce.sqlite");
  const app = await startServer({ database });
  try {
    assert.equal((await fetch(app.url)).status, 200);
    const state = await (await fetch(app.url + "/api/demo")).json();
    assert.equal(state.purchases, 0);
    assert.equal(state.outbox, 0);
    const response = await fetch(app.url + "/commerce/v1/capabilities");
    assert.equal(response.status, 200);
    const descriptor = await response.json();
    assert.ok(valid("#/$defs/ProviderCapabilities", descriptor));
    assert.deepEqual(Object.keys(descriptor.profiles).sort(), [
      "accountLifecycle",
      "entitlements",
      "events",
      "verification",
    ]);
    assert.deepEqual(descriptor.bindings, { rest: "1.0" });
    assert.equal(
      descriptor.stores.google.serverNotifications.implementation,
      false,
    );
    assert.equal(descriptor.fixtureOnly, true);
  } finally {
    await app.close();
  }
  const reopened = new Commerce(database);
  assert.equal(reopened.counts().purchases, 0);
  reopened.close();
  rmSync(dir, { recursive: true });
});

import { credentials, TOKENS, evidence } from "../src/fixtures.mjs";
async function post(app, path, input, role = "server") {
  const response = await fetch(app.url + path, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      ...(role ? { authorization: `Bearer ${credentials[role]}` } : {}),
    },
    body: JSON.stringify(input),
  });
  return { status: response.status, body: await response.json() };
}
test("milestone 2: valid, repeated, invalid, pending, upstream outage, unsupported store and auth", async () => {
  const app = await startServer();
  try {
    const path = "/commerce/v1/purchases/verify";
    const validInput = evidence(TOKENS.alice);
    const accepted = await post(
      app,
      path,
      { ...validInput, userId: "user_bob" },
      "verification",
    );
    assert.equal(accepted.status, 200);
    assert.equal(accepted.body.isValid, true);
    assert.ok(valid("#/$defs/VerifyPurchaseResult", accepted.body));
    assert.deepEqual(await post(app, path, validInput), accepted);
    assert.equal(app.commerce.counts().purchases, 1);
    assert.equal(
      app.commerce.db.prepare("SELECT user_id FROM purchases").get().user_id,
      null,
    );
    assert.equal(
      (await post(app, path, evidence(TOKENS.invalid))).body.isValid,
      false,
    );
    assert.equal(
      (await post(app, path, evidence(TOKENS.pending))).body.state,
      "PENDING",
    );
    const outage = await post(app, path, evidence(TOKENS.outage));
    assert.equal(outage.status, 502);
    assert.equal(outage.body.error.code, "VERIFICATION_FAILED");
    assert.equal(
      (await post(app, path, { store: "future_store" })).status,
      422,
    );
    assert.equal((await post(app, path, { store: "google" })).status, 400);
    assert.equal((await post(app, path, validInput, null)).status, 401);
    assert.equal(app.commerce.counts().purchases, 1);
  } finally {
    await app.close();
  }
});

test("milestone 3: first-claim policy, simultaneous ownership, tokenless reads and role isolation", async () => {
  const app = await startServer();
  try {
    const purchase = evidence(TOKENS.alice);
    await post(app, "/commerce/v1/purchases/verify", purchase);
    assert.equal(
      (
        await post(app, "/commerce/v1/purchases/bind", {
          ...purchase,
          userId: "user_bob",
        })
      ).body.bound,
      false,
    );
    const attempts = await Promise.all(
      Array.from({ length: 20 }, (_, i) =>
        post(app, "/commerce/v1/purchases/bind", {
          ...purchase,
          userId: i % 2 ? "user_bob" : "user_alice",
        }),
      ),
    );
    assert.deepEqual(
      attempts.map((a) => a.body.bound),
      Array.from({ length: 20 }, (_, i) => i % 2 === 0),
    );
    assert.equal(app.commerce.status("user_alice").active, true);
    assert.equal(app.commerce.status("user_bob").active, false);
    const url = app.url + "/commerce/v1/entitlements?userId=user_alice";
    const response = await fetch(url, {
      headers: { authorization: `Bearer ${credentials.server}` },
    });
    const read = await response.json();
    assert.ok(valid("#/$defs/EntitlementsResult", read));
    assert.ok(!JSON.stringify(read).includes(TOKENS.alice));
    assert.equal(
      (
        await fetch(url, {
          headers: { authorization: `Bearer ${credentials.verification}` },
        })
      ).status,
      403,
    );
    assert.equal(
      (
        await post(
          app,
          "/commerce/v1/purchases/bind",
          { store: "invalid" },
          "verification",
        )
      ).status,
      403,
    );
    assert.equal(
      (await post(app, "/commerce/v1/purchases/bind", {}, null)).status,
      401,
    );
    assert.deepEqual(
      (
        await post(app, "/commerce/v1/purchases/bind", {
          ...evidence("unknown"),
          userId: "user_bob",
        })
      ).body,
      { bound: false },
    );
  } finally {
    await app.close();
  }
});

test("app connection: session chooses user; pending/cancel/failure never open Premium", async () => {
  const app = await startServer();
  try {
    const login = await fetch(app.url + "/api/session", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ alias: "alice" }),
    });
    const cookie = login.headers.get("set-cookie").split(";")[0];
    const headers = { "content-type": "application/json", cookie };
    for (const scenario of ["pending", "canceled", "invalid"]) {
      const response = await fetch(app.url + "/api/checkout", {
        method: "POST",
        headers,
        body: JSON.stringify({ scenario }),
      });
      assert.equal(response.status, 200);
      assert.equal(app.commerce.status("user_alice").active, false);
    }
    const checkout = await fetch(app.url + "/api/checkout", {
      method: "POST",
      headers,
      body: JSON.stringify({ scenario: "paid", userId: "user_bob" }),
    });
    assert.equal((await checkout.json()).outcome, "fulfilled");
    assert.equal(app.commerce.status("user_alice").active, true);
    assert.equal(app.commerce.status("user_bob").active, false);
    assert.equal(
      (await fetch(app.url + "/api/premium-note", { headers })).status,
      200,
    );
    assert.equal((await fetch(app.url + "/api/premium-note")).status, 401);
  } finally {
    await app.close();
  }
});

test("milestone 4: cancellation preserves access, exact expiry closes before notification, atomic rollback and dedup", async () => {
  const app = await startServer();
  try {
    const c = app.commerce;
    const purchase = evidence(TOKENS.alice);
    c.verify(purchase);
    c.bind({ ...purchase, userId: "user_alice" });
    const count = c.counts();
    const original = c.purchase(TOKENS.alice);
    assert.throws(
      () => c.observe(TOKENS.alice, "cancel", "cancel-rollback", true),
      /Injected/,
    );
    assert.deepEqual(c.counts(), count);
    assert.deepEqual(c.purchase(TOKENS.alice), original);
    c.observe(TOKENS.alice, "cancel", "cancel-rollback");
    assert.equal(c.status("user_alice").active, true);
    assert.equal(c.status("user_alice").subscription.willRenew, false);
    assert.equal(c.counts().outbox, 3);
    c.observe(TOKENS.alice, "cancel", "cancel-rollback");
    c.observe(TOKENS.alice, "cancel", "another-cancel");
    assert.equal(c.counts().outbox, 3);
    c.setTime(original.expires_at - 1);
    assert.equal(c.status("user_alice").active, true);
    c.setTime(original.expires_at);
    assert.equal(c.status("user_alice").active, false);
    assert.equal(c.purchase(TOKENS.alice).state, "Active");
    assert.deepEqual(c.entitlements("user_alice").productIds, []);
    c.observe(TOKENS.alice, "expire", "expire-1");
    assert.equal(c.purchase(TOKENS.alice).state, "Expired");
    assert.equal(c.counts().outbox, 5);
    const events = c.db
      .prepare("SELECT body FROM outbox")
      .all()
      .map((r) => JSON.parse(r.body));
    assert.deepEqual(
      events.map((e) => e.eventType),
      [
        "subscription.started",
        "entitlement.granted",
        "subscription.canceled",
        "subscription.expired",
        "entitlement.revoked",
      ],
    );
    assert.ok(events.every((e) => valid("#/$defs/CommerceEvent", e)));
    assert.ok(events.every((e) => !JSON.stringify(e).includes(TOKENS.alice)));
    assert.equal(events[2].subscription.active, true);
    assert.equal(events[4].subscription.active, false);
  } finally {
    await app.close();
  }
});
test("binding after expiry coalesces stale grants into no entitlement event", async () => {
  const app = await startServer();
  try {
    const c = app.commerce;
    c.verify(evidence(TOKENS.alice));
    c.setTime(c.purchase(TOKENS.alice).expires_at);
    c.bind({ ...evidence(TOKENS.alice), userId: "user_alice" });
    assert.equal(c.status("user_alice").active, false);
    assert.equal(c.counts().outbox, 1);
  } finally {
    await app.close();
  }
});

test("milestone 6: reopen both databases, resume pending delivery, preserve ownership and inbox dedup", async () => {
  const dir = mkdtempSync("data/recovery-test-");
  const database = join(dir, "commerce.sqlite");
  let now = Date.now();
  let app = await startServer({ database, wallNow: () => now });
  let eventBody, deliveryId, secret;
  try {
    app.commerce.verify(evidence(TOKENS.alice));
    app.commerce.bind({ ...evidence(TOKENS.alice), userId: "user_alice" });
    app.inbox.lostAckNext = 1;
    await app.dispatch();
    assert.equal(app.inbox.count(), 2);
    const pending = app.commerce.db
      .prepare("SELECT * FROM outbox WHERE status='pending'")
      .get();
    eventBody = pending.body;
    deliveryId = pending.delivery_id;
    secret = app.secret;
    await app.close();
    now += 1000;
    app = await startServer({ database, wallNow: () => now });
    assert.equal(app.secret, secret);
    assert.equal(app.commerce.status("user_alice").active, true);
    assert.equal(app.inbox.count(), 2);
    assert.equal(
      app.commerce.bind({ ...evidence(TOKENS.alice), userId: "user_bob" })
        .bound,
      false,
    );
    const retry = await app.dispatch();
    assert.equal(retry[0].httpStatus, 200);
    assert.equal(app.inbox.count(), 2);
    const saved = app.commerce.db
      .prepare("SELECT * FROM outbox WHERE delivery_id=?")
      .get(deliveryId);
    assert.equal(saved.body, eventBody);
    assert.equal(saved.status, "delivered");
  } finally {
    await app.close();
    rmSync(dir, { recursive: true });
  }
});

test("erasure is atomic, removes provider identity and preserves another owner", async () => {
  const app = await startServer();
  try {
    const c = app.commerce;
    for (const alias of ["alice", "bob"]) {
      c.verify(evidence(TOKENS[alias]));
      c.bind({ ...evidence(TOKENS[alias]), userId: `user_${alias}` });
    }
    await app.dispatch();
    const before = c.inspect();
    c.db.exec(
      "CREATE TRIGGER fail_erasure BEFORE UPDATE OF erased ON purchases BEGIN SELECT RAISE(ABORT, 'injected erasure failure'); END",
    );
    assert.equal(
      (await post(app, "/commerce/v1/users/erase", { userId: "user_alice" }))
        .status,
      500,
    );
    assert.deepEqual(c.inspect(), before);
    c.db.exec("DROP TRIGGER fail_erasure");
    const erased = await post(app, "/commerce/v1/users/erase", {
      userId: "user_alice",
    });
    assert.deepEqual(erased, { status: 202, body: { accepted: true } });
    assert.deepEqual(
      await post(app, "/commerce/v1/users/erase", { userId: "user_alice" }),
      erased,
    );
    for (const table of ["purchases", "outbox", "delivery_attempts"])
      assert.equal(
        JSON.stringify(c.db.prepare(`SELECT * FROM ${table}`).all()).includes(
          "user_alice",
        ),
        false,
        table,
      );
    assert.equal(c.status("user_alice").active, false);
    assert.equal(c.status("user_bob").active, true);
    assert.equal(
      c.bind({ ...evidence(TOKENS.alice), userId: "user_alice" }).bound,
      false,
    );
    assert.equal(
      c.bind({ ...evidence(TOKENS.alice), userId: "user_bob" }).bound,
      false,
    );
    assert.ok(
      app.inbox.db
        .prepare("SELECT * FROM inbox WHERE json_extract(body,'$.userId')=?")
        .get("user_alice"),
      "Provider erasure does not claim to erase recipient copies",
    );
    assert.equal(
      (await post(app, "/commerce/v1/users/erase", {}, "verification")).status,
      403,
    );
  } finally {
    await app.close();
  }
});

test("app erasure waits for delivery, erases recipient copies and survives a retry and restart", async () => {
  const dir = mkdtempSync("data/erasure-test-");
  const database = join(dir, "commerce.sqlite");
  let app = await startServer({ database });
  try {
    const c = app.commerce;
    for (const alias of ["alice", "bob"]) {
      c.verify(evidence(TOKENS[alias]));
      c.bind({ ...evidence(TOKENS[alias]), userId: `user_${alias}` });
    }
    const event = c.db
      .prepare("SELECT * FROM outbox WHERE json_extract(body,'$.userId')=?")
      .get("user_alice");
    const { delivery } = await import("../src/webhooks.mjs");
    const envelope = delivery({
      event: JSON.parse(event.body),
      body: event.body,
      timestamp: Math.floor(Date.now() / 1000),
      secrets: [app.secret],
      deliveryId: event.delivery_id,
    });
    const login = await fetch(app.url + "/api/session", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ alias: "alice" }),
    });
    const cookie = login.headers.get("set-cookie").split(";")[0];
    const [, erased] = await Promise.all([
      app.dispatch(),
      fetch(app.url + "/api/erase", {
        method: "POST",
        headers: { "content-type": "application/json", cookie },
        body: JSON.stringify({ userId: "user_bob" }),
      }),
    ]);
    assert.equal(erased.status, 200);
    assert.equal(
      (await (await fetch(app.url + "/api/me", { headers: { cookie } })).json())
        .userId,
      null,
    );
    assert.equal(
      (await fetch(app.url + "/api/premium-note", { headers: { cookie } }))
        .status,
      401,
    );
    assert.equal(c.status("user_bob").active, true);
    for (const db of [c.db, app.inbox.db]) {
      const names = db
        .prepare("SELECT name FROM sqlite_master WHERE type='table'")
        .all();
      for (const { name } of names)
        assert.equal(
          JSON.stringify(db.prepare(`SELECT * FROM ${name}`).all()).includes(
            "user_alice",
          ),
          false,
          name,
        );
    }
    const count = app.inbox.count();
    await app.close();
    app = await startServer({ database });
    assert.equal(app.commerce.status("user_alice").active, false);
    assert.equal(app.commerce.status("user_bob").active, true);
    assert.equal(
      app.commerce.bind({ ...evidence(TOKENS.alice), userId: "user_alice" })
        .bound,
      false,
    );
    const replay = await fetch(app.url + "/webhooks/commerce", {
      method: "POST",
      headers: envelope.headers,
      body: event.body,
    });
    assert.deepEqual(await replay.json(), { accepted: true, duplicate: true });
    assert.equal(app.inbox.count(), count);
    assert.equal(
      JSON.stringify(
        app.inbox.db.prepare("SELECT * FROM inbox").all(),
      ).includes("user_alice"),
      false,
    );
  } finally {
    await app.close();
    rmSync(dir, { recursive: true });
  }
});
