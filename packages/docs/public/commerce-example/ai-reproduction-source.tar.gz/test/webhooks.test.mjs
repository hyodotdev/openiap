import { test } from "node:test";
import assert from "node:assert/strict";
import {
  signatureVectors,
  lifecycleVectors,
  createRestAdapter,
  runConformance,
} from "openiap-commerce-protocol/conformance";
import Ajv from "ajv/dist/2020.js";
import { writeFileSync } from "node:fs";
import {
  sign,
  verify,
  classifyResponse,
  delivery,
  eventsAdapter,
} from "../src/webhooks.mjs";
import { startServer } from "../src/server.mjs";
import { evidence, TOKENS, credentials } from "../src/fixtures.mjs";
test("published signature vectors, rotation, rejection vectors and response semantics", () => {
  for (const vector of signatureVectors.cases) {
    const signatures = [
      sign(vector),
      ...(vector.previousSecret
        ? [sign({ ...vector, secret: vector.previousSecret })]
        : []),
    ].join(",");
    assert.equal(signatures, vector.expected, vector.name);
    for (const secret of [
      vector.secret,
      ...(vector.previousSecret ? [vector.previousSecret] : []),
    ])
      assert.equal(
        verify({
          ...vector,
          signature: vector.presentedHeader || signatures,
          secrets: [secret],
          now: vector.timestamp,
        }),
        true,
        vector.name,
      );
  }
  for (const vector of signatureVectors.rejections)
    assert.equal(
      verify({
        ...vector,
        signature: vector.presentedSignature,
        secrets: [vector.secret],
        now: vector.receiverNow || vector.timestamp,
      }),
      false,
      vector.name,
    );
  for (const c of signatureVectors.responseSemantics.cases)
    assert.equal(classifyResponse(c.status), c.action);
  assert.equal(classifyResponse("timeout"), "retry");
  assert.equal(classifyResponse("connection-error"), "retry");
});
test("milestone 5: HTTP 503 retry, fresh signing, lost acknowledgement, tamper rejection and bounded dead letter", async () => {
  let now = Date.now();
  const app = await startServer({ wallNow: () => now, retryBase: 1000 });
  try {
    const c = app.commerce;
    c.verify(evidence(TOKENS.alice));
    app.inbox.failNext = 1;
    const first = await app.dispatch();
    assert.equal(first[0].httpStatus, 503);
    assert.equal(app.inbox.count(), 0);
    assert.deepEqual(await app.dispatch(), []);
    now += 1000;
    app.inbox.lostAckNext = 1;
    const second = await app.dispatch();
    assert.equal(second[0].httpStatus, "connection-error");
    assert.equal(app.inbox.count(), 1);
    now += 2000;
    const third = await app.dispatch();
    assert.equal(third[0].httpStatus, 200);
    assert.equal(app.inbox.count(), 1);
    const attempts = c.db.prepare("SELECT * FROM delivery_attempts").all();
    assert.equal(new Set(attempts.map((a) => a.delivery_id)).size, 1);
    assert.equal(new Set(attempts.map((a) => a.event_id)).size, 1);
    assert.equal(new Set(attempts.map((a) => a.body)).size, 1);
    assert.equal(new Set(attempts.map((a) => a.signature)).size, 3);
    const row = c.db.prepare("SELECT * FROM outbox").get();
    const envelope = delivery({
      event: JSON.parse(row.body),
      body: row.body,
      timestamp: Math.floor(now / 1000),
      secrets: [app.secret],
      deliveryId: row.delivery_id,
    });
    const tampered = await fetch(app.url + "/webhooks/commerce", {
      method: "POST",
      headers: envelope.headers,
      body: row.body + " ",
    });
    assert.equal(tampered.status, 401);
    const wrongHeader = await fetch(app.url + "/webhooks/commerce", {
      method: "POST",
      headers: {
        ...envelope.headers,
        "openiap-event-id": "untrusted-header-id",
      },
      body: row.body,
    });
    assert.equal(wrongHeader.status, 200);
    assert.equal(app.inbox.count(), 1);
    c.bind({ ...evidence(TOKENS.alice), userId: "user_alice" });
    app.inbox.alwaysFail = true;
    for (let i = 0; i < 4; i++) {
      await app.dispatch();
      now += 8000;
    }
    assert.equal(
      c.db
        .prepare("SELECT count(*) AS n FROM outbox WHERE status='dead-letter'")
        .get().n,
      1,
    );
    assert.deepEqual(await app.dispatch(), []);
  } finally {
    await app.close();
  }
});
test("portable runner passes all four profiles and REST in the explicit fixture environment", async () => {
  const app = await startServer();
  try {
    const report = await runConformance({
      adapters: [createRestAdapter({ baseUrl: app.url, fetch, credentials })],
      Ajv,
      credentials,
      eventsAdapter,
    });
    writeFileSync("evidence/conformance.json", JSON.stringify(report, null, 2));
    assert.equal(
      report.ok,
      true,
      JSON.stringify(report.results.filter((r) => !r.ok)),
    );
    assert.ok(report.results.length > 42);
    const priorCaseIds = [
      "capabilities.version-agreement",
      "providerCapabilities.success.contract",
      "subscriptionStatus.auth.missing-credential",
      "subscriptionStatus.auth.unknown-credential",
      "subscriptionStatus.auth.verification-role-refused",
      "subscriptionStatus.auth.precedes-validation",
      "subscriptionStatus.auth.precedes-structural-validation",
      "subscriptionStatus.input.missing-required-member",
      "subscriptionStatus.success.contract",
      "entitlements.auth.missing-credential",
      "entitlements.auth.unknown-credential",
      "entitlements.auth.verification-role-refused",
      "entitlements.auth.precedes-validation",
      "entitlements.auth.precedes-structural-validation",
      "entitlements.input.missing-required-member",
      "entitlements.success.contract",
      "verifyPurchase.auth.missing-credential",
      "verifyPurchase.auth.unknown-credential",
      "verifyPurchase.input.missing-required-member",
      "bindPurchase.auth.missing-credential",
      "bindPurchase.auth.unknown-credential",
      "bindPurchase.auth.verification-role-refused",
      "bindPurchase.auth.precedes-validation",
      "bindPurchase.auth.precedes-structural-validation",
      "bindPurchase.input.missing-required-member",
      "bindPurchase.success.contract",
      "bindPurchase.input.unknown-member-ignored",
      "bindPurchase.idempotent.repeat",
      "eraseUser.auth.missing-credential",
      "eraseUser.auth.unknown-credential",
      "eraseUser.auth.verification-role-refused",
      "eraseUser.auth.precedes-validation",
      "eraseUser.auth.precedes-structural-validation",
      "eraseUser.input.missing-required-member",
      "eraseUser.success.contract",
      "eraseUser.input.unknown-member-ignored",
      "eraseUser.idempotent.repeat",
      "verifyPurchase.store.unsupported",
      "verifyPurchase.input.mismatched-evidence",
      "providerCapabilities.honesty.binding-declared",
      "bindPurchase.unknown-evidence.not-bound",
      "entitlements.unknown-user.empty",
    ];
    assert.ok(
      priorCaseIds.every((id) =>
        report.results.some((current) => current.id === id),
      ),
      "The completed run must not drop any original check",
    );
    assert.ok(report.results.every((r) => r.ok));
  } finally {
    await app.close();
  }
});
test("published lifecycle vectors: 32 entitlement, 64 emission and 4 first-binding cases", () => {
  for (const row of lifecycleVectors.entitlement.cases)
    assert.equal(eventsAdapter.entitled(row), row.entitled, row.name);
  for (const row of lifecycleVectors.emission.cases)
    assert.deepEqual(eventsAdapter.emission(row), row.emit, row.name);
  for (const row of lifecycleVectors.binding.cases)
    assert.deepEqual(eventsAdapter.coalesceAtBinding(row), row.emit, row.name);
});
