import {
  runConformance,
  createRestAdapter,
} from "openiap-commerce-protocol/conformance";
import Ajv from "ajv/dist/2020.js";
import { mkdirSync, writeFileSync } from "node:fs";
import { startServer } from "../src/server.mjs";
import { eventsAdapter } from "../src/webhooks.mjs";
import { credentials } from "../src/fixtures.mjs";
mkdirSync("evidence", { recursive: true });
const app = await startServer();
try {
  const report = await runConformance({
    adapters: [createRestAdapter({ baseUrl: app.url, fetch, credentials })],
    Ajv,
    credentials,
    eventsAdapter,
  });
  writeFileSync("evidence/conformance.json", JSON.stringify(report, null, 2));
  console.log(
    JSON.stringify(
      {
        ok: report.ok,
        passed: report.results.filter((r) => r.ok).length,
        total: report.results.length,
        failures: report.results.filter((r) => !r.ok),
      },
      null,
      2,
    ),
  );
  process.exitCode = report.ok ? 0 : 1;
} finally {
  await app.close();
}
