import { mkdirSync } from "node:fs";
import { spawnSync } from "node:child_process";
mkdirSync("data", { recursive: true });
mkdirSync("evidence", { recursive: true });
const result = spawnSync(
  process.execPath,
  ["--test", "test/commerce.test.mjs", "test/webhooks.test.mjs"],
  { stdio: "inherit" },
);
process.exit(result.status ?? 1);
