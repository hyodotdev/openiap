import { chromium } from "playwright";
import {
  mkdirSync,
  writeFileSync,
  readFileSync,
  mkdtempSync,
  symlinkSync,
  readdirSync,
} from "node:fs";
import { execFileSync } from "node:child_process";
import { resolve, join } from "node:path";
import { pathToFileURL } from "node:url";
import { createHash } from "node:crypto";
import assert from "node:assert/strict";
mkdirSync("data", { recursive: true });
const root = process.cwd();
const stamp = new Date().toISOString().replaceAll(":", "-");
const output = join("evidence", "screens", stamp);
mkdirSync(output, { recursive: true });
const profile = mkdtempSync("data/headless-profile-");
const browser = await chromium.launchPersistentContext(profile, {
  headless: true,
  viewport: { width: 1365, height: 1080 },
});
const report = {
  capturedAt: new Date().toISOString(),
  browser: browser.browser()?.version(),
  screens: [],
  errors: [],
};
try {
  for (const checkpoint of readdirSync("evidence/checkpoints")
    .filter((f) => f.endsWith(".tar.gz"))
    .sort()) {
    const stage = Number(checkpoint[0]);
    const dir = mkdtempSync("data/replay-");
    execFileSync("tar", [
      "-xzf",
      resolve("evidence/checkpoints", checkpoint),
      "-C",
      dir,
    ]);
    symlinkSync(resolve("node_modules"), join(dir, "node_modules"), "dir");
    const { startServer } = await import(
      pathToFileURL(resolve(dir, "src/server.mjs"))
    );
    const database = resolve(dir, "commerce.sqlite");
    let app = await startServer({ database });
    const page = await browser.newPage();
    page.on("pageerror", (error) =>
      report.errors.push({ checkpoint, message: error.message }),
    );
    const api = [];
    page.on("response", async (response) => {
      if (response.url().includes("/api/")) {
        try {
          api.push({
            path: new URL(response.url()).pathname,
            status: response.status(),
            body: await response.json(),
          });
        } catch {}
      }
    });
    try {
      await page.goto(app.url);
      if (stage === 1)
        await page.locator("#state").filter({ hasText: "purchases" }).waitFor();
      if (stage === 2) {
        const response = await fetch(
          app.url + "/commerce/v1/purchases/verify",
          {
            method: "POST",
            headers: {
              "content-type": "application/json",
              authorization: "Bearer local-fixture-verification-key",
            },
            body: JSON.stringify({
              store: "google",
              google: { purchaseToken: "fictional-alice-premium" },
            }),
          },
        );
        api.push({
          path: "/commerce/v1/purchases/verify",
          status: response.status,
          body: await response.json(),
        });
        await page.reload();
        await page.locator("#state").filter({ hasText: "purchases" }).waitFor();
      }
      if (stage >= 3) {
        await page.locator("#buy").waitFor({ state: "visible" });
        await page.waitForFunction(
          () => !document.querySelector("#buy").disabled,
        );
        await page.locator("#buy").click();
        await page.locator("#premium-note").waitFor({ state: "visible" });
      }
      if (stage >= 4) {
        await page.locator("#cancel").click();
        await page.waitForFunction(
          () =>
            document.querySelector("#renewal").textContent === "Renewal is off",
        );
      }
      if (stage >= 5) {
        await page.locator(".inspect summary").click();
        await page.locator("#deliver").click();
        await page.waitForFunction(() =>
          document.querySelector("#response").textContent.includes("attempts"),
        );
      }
      if (stage === 6) {
        await page.close();
        await app.close();
        app = await startServer({ database });
        const recovered = await browser.newPage();
        await recovered.goto(app.url);
        await recovered.locator("#premium-note").waitFor({ state: "visible" });
        await recovered.locator("#expire").click();
        await recovered.waitForFunction(
          () => document.querySelector("#access").textContent === "Free plan",
        );
        assert.equal(
          await recovered.locator("#premium-note").isVisible(),
          false,
        );
        await recovered.screenshot({
          path: join(output, checkpoint.replace(".tar.gz", ".png")),
          fullPage: true,
        });
        await recovered.close();
      } else
        await page.screenshot({
          path: join(output, checkpoint.replace(".tar.gz", ".png")),
          fullPage: true,
        });
      report.screens.push({
        checkpoint,
        checkpointSha256: createHash("sha256")
          .update(readFileSync(join("evidence/checkpoints", checkpoint)))
          .digest("hex"),
        image: checkpoint.replace(".tar.gz", ".png"),
        state: await (await fetch(app.url + "/api/demo")).json(),
        responses: api,
      });
    } finally {
      await page.close().catch(() => {});
      await app.close();
    }
  }
} finally {
  await browser.close();
  writeFileSync(
    join(output, "capture-report.json"),
    JSON.stringify(report, null, 2),
  );
}
assert.equal(report.errors.length, 0, JSON.stringify(report.errors));
console.log(
  JSON.stringify({
    output,
    screens: report.screens.length,
    pageErrors: report.errors.length,
  }),
);
