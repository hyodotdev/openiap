import { execFileSync } from "node:child_process";
import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { createHash } from "node:crypto";
const milestone = process.argv[2];
if (!/^\d-[a-z-]+$/.test(milestone || ""))
  throw new Error("Provide milestone name");
mkdirSync("evidence/checkpoints", { recursive: true });
const archive = `evidence/checkpoints/${milestone}.tar.gz`;
execFileSync("tar", [
  "-czf",
  archive,
  "src",
  "public",
  "test",
  "scripts",
  "package.json",
  "package-lock.json",
]);
writeFileSync(
  `${archive}.sha256`,
  createHash("sha256").update(readFileSync(archive)).digest("hex") +
    `  ${archive}\n`,
);
console.log(archive);
