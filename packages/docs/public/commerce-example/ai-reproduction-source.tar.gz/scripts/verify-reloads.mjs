import { chromium } from "playwright";
import { mkdtempSync, mkdirSync, writeFileSync } from "node:fs";
import { startServer } from "../src/server.mjs";
import assert from "node:assert/strict";
mkdirSync("data", { recursive: true });
mkdirSync("evidence", { recursive: true });
const app = await startServer();
const profile = mkdtempSync("data/reload-profile-");
const context = await chromium.launchPersistentContext(profile, {
  headless: true,
  viewport: { width: 1365, height: 1080 },
});
const page = await context.newPage();
const results = [];
const errors = [];
page.on("pageerror", (e) => errors.push(e.message));
async function waitReady() {
  await page.waitForFunction(
    () =>
      !document.querySelector("#buy").disabled &&
      document.querySelector("#notice").textContent.includes("Alice"),
  );
}
try {
  await page.goto(app.url);
  await waitReady();
  for (const [action, notice, access] of [
    ["#buy", "Premium is active", "Premium is active"],
    ["#cancel", "Renewal is off", "Premium is active"],
    ["#expire", "paid period has ended", "Free plan"],
  ]) {
    await page.locator(action).click();
    await page.waitForFunction(() => !document.querySelector("#buy").disabled);
    await page.reload();
    await waitReady();
    const actual = {
      action,
      banner: await page.locator("#notice").innerText(),
      access: await page.locator("#access").innerText(),
      noteVisible: await page.locator("#premium-note").isVisible(),
    };
    assert.ok(actual.banner.includes(notice), actual.banner);
    assert.equal(actual.access, access);
    assert.equal(actual.noteVisible, access === "Premium is active");
    results.push(actual);
  }
  await page.setViewportSize({ width: 390, height: 844 });
  assert.equal(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= innerWidth,
    ),
    true,
  );
  await page.screenshot({
    path: "evidence/reload-expired-mobile.png",
    fullPage: true,
  });
  assert.equal(errors.length, 0);
  writeFileSync(
    "evidence/reload-checks.json",
    JSON.stringify({ results, pageErrors: errors, overflow: false }, null, 2),
  );
  console.log(
    JSON.stringify({
      reloads: results.length,
      passed: true,
      pageErrors: errors.length,
      mobileOverflow: false,
    }),
  );
} finally {
  await context.close();
  await app.close();
}
