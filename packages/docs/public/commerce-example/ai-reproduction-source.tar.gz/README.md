# Field Notes: local Commerce Protocol demo

Alice can buy fictional Premium, cancel renewal while keeping paid access, and lose access exactly at expiry. Bob cannot claim Alice’s purchase. The Premium note is protected by the backend, not just hidden by the browser.

```sh
npm ci
npm test
npm start
```

Open **http://127.0.0.1:5197**. Requires Node.js 24 or newer; tested with Node 24.16.0 and npm 11.13.0. No Bun, OpenIAP checkout, account, credentials, or cloud service is needed. `npm test` creates its own output directories and temporary databases.

1. As Alice, click **Buy Premium · fixture**. The note opens only after verification, binding and an access read succeed.
2. Switch to Bob and click **Try Alice’s purchase as Bob**. The claim returns `bound: false`; Bob stays on the free plan.
3. Switch back to Alice and click **Cancel renewal**. The note stays readable through the paid period.
4. Click **Advance to paid expiry · fixture**. The controlled clock reaches the exclusive expiry boundary and the note locks.
5. Expand **Inspect the local commerce connection** to inspect real state, events, delivery attempts and responses. The worker delivers due events every second. **Deliver queued events** also runs it on demand.

“Try a checkout result” offers pending, canceled, invalid and unavailable-verifier scenarios. Each keeps a new free account locked. Reloading reflects persisted access, including canceled and expired subscriptions.

The SQLite databases persist across restarts. To replay from an empty database without deleting previous runs:

```sh
DATABASE=data/fresh-review.sqlite PORT=5197 npm start
```

Use a new filename each time. Stop the existing server before reusing its port. A repeated fixture purchase is idempotent and does not create a new billing period.

## Scope and evidence

This is a fictional Google-shaped adapter and local fixture-session system. It uses `openiap-commerce-protocol@0.1.0` (protocol 1.0), Node HTTP, SQLite, Ajv and plain HTML/CSS/JavaScript. It owns the commerce backend and signed event receiver in one local process, using separate commerce and inbox databases. Its descriptor explicitly identifies a fixture environment and declares all four profiles over REST. Store support describes the fixture adapter only; no real Google API or notification channel is connected.

- `npm test`: 13 local test groups, including 100 lifecycle vectors, signature vectors, failure cases and SQLite recovery. The portable runner must pass, and every case exercised before completion must remain in the run.
- `npm run conformance`: the published portable runner; **46/46 pass**, exit code 0, including all earlier cases and the added profile checks. This is fixture conformance, not real store certification.
- `npm run capture`: reruns the immutable milestone source archives in isolated local servers and captures their actual screens. First run `PLAYWRIGHT_BROWSERS_PATH=./data/playwright npx playwright install chromium`.
- `PLAYWRIGHT_BROWSERS_PATH=./data/playwright node scripts/verify-reloads.mjs`: purchase, cancellation and expiry reload checks plus a 390px viewport overflow check.

See [the implementation and verification report](REPORT.md), [the saved conformance result](evidence/conformance.json), and [six checkpoint captures](evidence/screens/2026-09-08T16-11-15.208Z/capture-report.json). Screens were captured by re-executing the saved sources after implementation; they are not a recording of the build session.

The public starting brief and reference are [INTEGRATE.md](https://github.com/hyodotdev/openiap-commerce-protocol-example/blob/e52900c2f040a0c9aa895e4a605b4f3e84940652/INTEGRATE.md) and [BUILD.md](https://github.com/hyodotdev/openiap-commerce-protocol-example/blob/e52900c2f040a0c9aa895e4a605b4f3e84940652/BUILD.md). The installed [SPEC.md](node_modules/openiap-commerce-protocol/SPEC.md) is the behavioral contract.

Real store verification, login, tenant isolation, public HTTPS destination protections, real store acknowledgement, and production operations remain unimplemented. No store or deployment conformance is claimed.

## Delete a fixture account

In Current access, open Account deletion and select Delete this fixture account.
The app removes provider identity and its own received event copies, then revokes
that user's sessions. Other users keep their records. The erased purchase cannot
be reclaimed in this run; use a new database for another clean walkthrough.

`eraseUser` returns HTTP 202 with `accepted: true`. It removes provider records
only. The app separately erases its inbox, retaining scoped event IDs without
user data so delayed retries cannot restore deleted content. The tests cover
rollback, active delivery, repeated requests, other-user isolation, and restart.
