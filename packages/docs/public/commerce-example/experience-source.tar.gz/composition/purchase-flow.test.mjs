import { test, expect } from "bun:test";
import { createPurchaseFlow } from "./purchase-flow.mjs";

test("denied or malformed fulfillment never reports success or finishes a purchase", async () => {
  for (const access of [
    undefined,
    null,
    { access: false },
    { productIds: [] },
    { productIds: ["another.product"] },
    { productIds: "premium.monthly" },
  ]) {
    let finishes = 0;
    const flow = createPurchaseFlow({
      purchase: async () => ({ status: "purchased", evidence: {} }),
      fulfill: async () => access,
      finish: async () => {
        finishes++;
      },
    });
    expect(await flow("premium.monthly")).toEqual({ status: "failed" });
    expect(finishes).toBe(0);
  }
});
