import { join } from "node:path";
import { rmSync } from "node:fs";
import { randomUUID } from "node:crypto";
import { WEBHOOK } from "openiap-commerce-protocol";
import { startLab } from "../server.mjs";
import { FIXTURE, CREDENTIALS } from "../provider.mjs";
import { startConsumer } from "../consumer.mjs";
import { deliver, sign } from "../webhooks.mjs";
import { startAppBackend } from "./app-backend.mjs";

export async function startExperience({ port = 0 } = {}) {
  const lab = startLab();
  const { runtime } = lab;
  let receiver, app, server;
  async function close() {
    await server?.stop(true);
    await app?.close();
    await receiver?.close();
    await lab.close();
    rmSync(lab.directory, { recursive: true, force: true });
  }
  try {
    receiver = startConsumer({
      secret: runtime.secret,
      path: join(lab.directory, "experience-inbox.sqlite"),
      now: runtime.now,
    });
    app = startAppBackend({
      path: join(lab.directory, "app.sqlite"),
      providers: {
        example: { baseUrl: runtime.baseUrl, credential: CREDENTIALS.server },
      },
      receiver,
      // This standalone demo has one fictional signed-in customer.
      resolveSession: () => FIXTURE.userId,
    });
    let baseUrl,
      changing = false;
    const flush = () =>
      deliver(runtime.provider, runtime.secret, runtime.now, (init) =>
        fetch(receiver.url, {
          ...init,
          redirect: "error",
          signal: AbortSignal.timeout(5000),
        }),
      );
    server = Bun.serve({
      hostname: "127.0.0.1",
      port,
      maxRequestBodySize: 32768,
      async fetch(request) {
        const url = new URL(request.url);
        const origin = request.headers.get("origin");
        if (url.origin !== baseUrl || (origin && origin !== baseUrl))
          return new Response("Local requests only", { status: 403 });
        if (request.method === "GET" && url.pathname === "/")
          return new Response(
            Bun.file(new URL("./experience.html", import.meta.url)),
            { headers: { "content-type": "text/html; charset=utf-8" } },
          );
        if (request.method === "GET" && url.pathname === "/purchase-flow.mjs")
          return new Response(
            Bun.file(new URL("./purchase-flow.mjs", import.meta.url)),
            { headers: { "content-type": "text/javascript" } },
          );
        if (
          (request.method === "POST" && url.pathname === "/app/purchase") ||
          (request.method === "GET" && url.pathname === "/app/access")
        ) {
          return fetch(app.url + url.pathname.slice(4), {
            method: request.method,
            headers: { "content-type": "application/json" },
            ...(request.method === "POST"
              ? { body: await request.text() }
              : {}),
            redirect: "error",
            signal: AbortSignal.timeout(5000),
          });
        }
        if (request.method === "GET" && url.pathname === "/demo/state")
          return Response.json({
            fixture: FIXTURE,
            purchases: runtime.provider.inspect().purchases,
            events: receiver.inspect(),
            connections: {
              app: app.url,
              provider: runtime.baseUrl,
              receiver: receiver.url,
            },
          });
        if (request.method !== "POST")
          return new Response("Not found", { status: 404 });
        if (url.pathname === "/demo/denied-purchase")
          return Response.json({ access: false });
        if (
          ![
            "/demo/cancel",
            "/demo/expire",
            "/demo/redeliver",
            "/demo/reopen",
          ].includes(url.pathname)
        )
          return new Response("Not found", { status: 404 });
        if (changing) return new Response("Action running", { status: 409 });
        changing = true;
        try {
          if (url.pathname === "/demo/reopen") {
            receiver.reopen();
            return Response.json({ savedEvents: receiver.count() });
          }
          if (
            !runtime.provider
              .inspect()
              .purchases.some((row) => row.userId === FIXTURE.userId)
          )
            return new Response("Complete a purchase first", { status: 409 });
          if (url.pathname === "/demo/redeliver") {
            const row = runtime.provider.db
              .query("SELECT body FROM outbox ORDER BY rowid DESC LIMIT 1")
              .get();
            if (!row) return new Response("No event yet", { status: 409 });
            const event = JSON.parse(row.body),
              timestamp = String(Math.floor(runtime.now() / 1000));
            return fetch(receiver.url, {
              method: "POST",
              body: row.body,
              redirect: "error",
              headers: {
                "content-type": WEBHOOK.contentType,
                [WEBHOOK.timestampHeader]: timestamp,
                [WEBHOOK.signatureHeader]: sign(
                  runtime.secret,
                  timestamp,
                  row.body,
                ),
                [WEBHOOK.eventIdHeader]: event.eventId,
              },
              signal: AbortSignal.timeout(5000),
            });
          }
          if (url.pathname === "/demo/expire") runtime.time = FIXTURE.expiresAt;
          runtime.provider.observe({
            id: randomUUID(),
            kind: url.pathname === "/demo/cancel" ? "cancel" : "expire",
            occurredAt: runtime.now(),
          });
          return Response.json({ deliveries: await flush() });
        } finally {
          changing = false;
        }
      },
    });
    baseUrl = `http://127.0.0.1:${server.port}`;
    return { url: baseUrl, close };
  } catch (error) {
    await close();
    throw error;
  }
}

if (import.meta.main) {
  const demo = await startExperience({
    port: Number(process.env.COMMERCE_EXPERIENCE_PORT ?? 5184),
  });
  console.log(
    `Paywall connection demo: ${demo.url}\nFictional store and Alice session. Real local HTTP, SQLite, and signed events.`,
  );
  for (const signal of ["SIGINT", "SIGTERM"])
    process.once(signal, async () => {
      await demo.close();
      process.exit(0);
    });
}
