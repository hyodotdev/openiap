import { test, expect } from "bun:test";
import { startExperience } from "./experience.mjs";
import { createPurchaseFlow } from "./purchase-flow.mjs";

test("paywall outcomes and lifecycle events execute through the running app and provider", async () => {
  const demo = await startExperience();
  const call = async (path, body) => {
    const response = await fetch(demo.url + path, {
      method: body === undefined ? "GET" : "POST",
      ...(body === undefined ? {} : { body: JSON.stringify(body) }),
    });
    expect(response.status).toBe(200);
    return response.json();
  };
  try {
    const initial = await call("/demo/state");
    expect(initial.purchases).toEqual([]);
    expect((await call("/app/access")).productIds).toEqual([]);
    const { fixture } = initial;
    let finishes = 0,
      fulfillments = 0,
      mode;
    const select = createPurchaseFlow({
      purchase: async () => ({
        status: ["purchased", "denied"].includes(mode) ? "purchased" : mode,
        evidence: {
          store: fixture.store,
          evidence: fixture.evidence,
          userId: "untrusted_bob",
        },
      }),
      fulfill: async (evidence) => {
        fulfillments++;
        return call(
          mode === "denied" ? "/demo/denied-purchase" : "/app/purchase",
          evidence,
        );
      },
      finish: async () => {
        finishes++;
      },
    });
    for (mode of ["pending", "canceled", "failed"]) {
      expect(await select(fixture.productId)).toEqual({ status: mode });
      expect(finishes).toBe(0);
      expect(fulfillments).toBe(0);
    }
    mode = "denied";
    expect(await select(fixture.productId)).toEqual({ status: "failed" });
    expect(finishes).toBe(0);
    expect((await call("/demo/state")).purchases).toEqual([]);
    mode = "purchased";
    const purchased = await select(fixture.productId);
    expect(purchased.status).toBe("fulfilled");
    expect(purchased.access.productIds).toEqual([fixture.productId]);
    expect(finishes).toBe(1);
    expect((await call("/demo/state")).purchases[0].userId).toBe(
      fixture.userId,
    );
    expect((await call("/app/access")).productIds).toEqual([fixture.productId]);
    await call("/demo/cancel", {});
    const canceled = await call("/demo/state");
    expect(canceled.purchases[0].willRenew).toBe(0);
    expect(canceled.events.map((event) => event.eventType)).toEqual([
      "entitlement.granted",
      "subscription.canceled",
    ]);
    expect((await call("/app/access")).productIds).toEqual([fixture.productId]);
    expect((await call("/app/access")).subscriptions[0].willRenew).toBe(false);
    expect((await call("/demo/redeliver", {})).duplicate).toBe(true);
    expect((await call("/demo/reopen", {})).savedEvents).toBe(2);
    await call("/demo/expire", {});
    expect((await call("/app/access")).productIds).toEqual([]);
    expect(
      (await call("/demo/state")).events.map((event) => event.eventType),
    ).toEqual([
      "entitlement.granted",
      "subscription.canceled",
      "subscription.expired",
      "entitlement.revoked",
    ]);
    expect(
      (
        await fetch(demo.url + "/demo/cancel", {
          method: "POST",
          headers: { origin: "https://untrusted.example" },
        })
      ).status,
    ).toBe(403);
  } finally {
    await demo.close();
  }
});
