import {
  fetchProducts,
  setScenario,
  purchase,
  fulfill,
  finish,
  finishCount,
  readAccess,
} from "./host.mjs";
import { createPurchaseFlow } from "./purchase-flow.mjs";
const [product] = await fetchProducts();
document.querySelector("#product").textContent = product.title;
document.querySelector("#price").textContent = product.displayPrice;
document.querySelector("#scenario").onchange = (e) =>
  setScenario(e.target.value);
const buy = document.querySelector("#buy");
const select = createPurchaseFlow({ purchase, fulfill, finish });
async function refresh() {
  const access = await readAccess();
  document.querySelector("#access").textContent = access.productIds.includes(
    product.id,
  )
    ? "Premium open"
    : "Locked";
  document.querySelector("#finishes").textContent = String(finishCount());
}
buy.onclick = async () => {
  buy.disabled = true;
  try {
    const result = await select(product.id);
    document.querySelector("#result").textContent = result.status;
    await refresh();
  } catch (error) {
    document.querySelector("#result").textContent = error.message;
  } finally {
    buy.disabled = false;
  }
};
document.querySelector("#result").textContent = "Ready";
await refresh();
