import { test, expect } from "bun:test";
import { startExperience } from "../reference/composition/experience.mjs";
import { createPurchaseFlow } from "./purchase-flow.mjs";

test("this paywall adapter uses its own running gateway and preserves host boundaries", async () => {
  const reference = await startExperience();
  const child = Bun.spawn(["bun", "server.mjs"], {
    cwd: import.meta.dir,
    env: { ...process.env, EXAMPLE_URL: reference.url, PORT: "0" },
    stdout: "pipe",
    stderr: "pipe",
  });
  try {
    const reader = child.stdout.getReader();
    const { value } = await reader.read();
    reader.releaseLock();
    const url = new TextDecoder()
      .decode(value)
      .match(/http:\/\/127\.0\.0\.1:\d+/)?.[0];
    expect(url).toBeDefined();
    const call = async (path, body) => {
      const r = await fetch(url + path, {
        method: body === undefined ? "GET" : "POST",
        ...(body === undefined
          ? {}
          : {
              body: JSON.stringify(body),
              headers: { "content-type": "application/json" },
            }),
      });
      expect(r.status).toBe(200);
      return r.json();
    };
    const { fixture } = await call("/api/fixture");
    expect((await call("/api/access")).productIds).toEqual([]);
    let mode,
      fulfills = 0,
      finishes = 0,
      finishFails = false;
    const select = createPurchaseFlow({
      purchase: async () => ({
        status: ["denied", "purchased"].includes(mode) ? "purchased" : mode,
        evidence: { store: fixture.store, evidence: fixture.evidence },
      }),
      fulfill: async (evidence) => {
        fulfills++;
        return call(
          mode === "denied" ? "/api/denied" : "/api/purchase",
          evidence,
        );
      },
      finish: async () => {
        if (finishFails) throw Error("Store finish unavailable");
        finishes++;
      },
    });
    for (mode of ["pending", "canceled", "failed"]) {
      expect((await select(fixture.productId)).status).toBe(mode);
      expect(fulfills).toBe(0);
      expect(finishes).toBe(0);
    }
    mode = "denied";
    expect((await select(fixture.productId)).status).toBe("failed");
    expect(finishes).toBe(0);
    expect((await call("/api/access")).productIds).toEqual([]);
    mode = "purchased";
    expect((await select(fixture.productId)).status).toBe("fulfilled");
    expect(finishes).toBe(1);
    expect((await call("/api/access")).productIds).toEqual([fixture.productId]);
    finishFails = true;
    expect((await select(fixture.productId)).status).toBe("finish-pending");
    expect(finishes).toBe(1);
    finishFails = false;
    expect((await select(fixture.productId)).status).toBe("fulfilled");
    expect(finishes).toBe(2);
    expect((await call("/api/fixture")).purchases).toHaveLength(1);
  } finally {
    child.kill();
    await child.exited;
    await reference.close();
  }
});
