let scenario = 'pending', finishes = 0;
export const setScenario = value => { scenario = value; };
export const finishCount = () => finishes;
export async function fetchProducts() {
  const {fixture} = await (await fetch('/api/fixture')).json();
  return [{id:fixture.productId,title:'Monthly Premium',displayPrice:'Fictional monthly plan'}];
}
export async function purchase(productId) {
  if (['pending','canceled','failed'].includes(scenario)) return {status:scenario};
  const {fixture}=await (await fetch('/api/fixture')).json();
  if(productId !== fixture.productId) throw Error('Unknown product');
  return {status:'purchased',evidence:{store:fixture.store,evidence:fixture.evidence}};
}
export async function fulfill(evidence) {
  const r=await fetch(scenario==='denied'?'/api/denied':'/api/purchase',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(evidence)});
  if(!r.ok) throw Error('Backend rejected purchase');
  return r.json();
}
export async function finish() { finishes++; }
export async function readAccess() { return (await fetch('/api/access')).json(); }
