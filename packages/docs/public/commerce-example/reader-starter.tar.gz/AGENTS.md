# Existing project fixture

This is a small existing Bun web paywall used to evaluate the OpenIAP guide.
Keep index.html, its experiment choice, and host.mjs unchanged. Connect only
app.mjs to the host's supplied product and purchase callbacks. Add tests.

The store callback and Alice session are fictional. The configured app backend
is the separately running reference at http://127.0.0.1:5194; HTTP and storage
are real. Do not implement another purchase provider or event receiver here.

Run npm start, then open http://127.0.0.1:5195. REPORT output from both the
reference tests and this project's own tests separately. No real store claim.
