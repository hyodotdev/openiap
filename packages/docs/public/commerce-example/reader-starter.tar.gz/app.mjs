import { fetchProducts, setScenario } from './host.mjs';
const [product] = await fetchProducts();
document.querySelector('#product').textContent=product.title;
document.querySelector('#price').textContent=product.displayPrice;
document.querySelector('#scenario').onchange=e=>setScenario(e.target.value);
document.querySelector('#buy').onclick=()=>{document.querySelector('#result').textContent='Not connected';};
