const backend = process.env.EXAMPLE_URL ?? 'http://127.0.0.1:5194';
const files = new Map([['/', 'index.html'], ['/host.mjs', 'host.mjs'], ['/app.mjs', 'app.mjs'], ['/purchase-flow.mjs', 'purchase-flow.mjs']]);
const api = new Map([['/api/fixture', '/demo/state'], ['/api/purchase', '/app/purchase'], ['/api/access', '/app/access'], ['/api/denied', '/demo/denied-purchase']]);
Bun.serve({hostname:'127.0.0.1',port:5195,async fetch(request){
  const path = new URL(request.url).pathname;
  if (files.has(path) && request.method === 'GET') return new Response(Bun.file(new URL(files.get(path), import.meta.url)),{headers:{'content-type':path === '/' ? 'text/html' : 'text/javascript'}});
  if(api.has(path)) return fetch(backend+api.get(path),{method:request.method,headers:{'content-type':'application/json'},...(request.method==='POST'?{body:await request.text()}:{}),redirect:'error',signal:AbortSignal.timeout(5000)});
  return new Response('Not found',{status:404});
}});
console.log('Reader paywall: http://127.0.0.1:5195');
